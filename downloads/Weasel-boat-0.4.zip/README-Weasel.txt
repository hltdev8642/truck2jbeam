Weasel Class Boat Pack
by Redeye

A fictional small & fast multi-purpose boat for Rigs of Rods (tested with 0.38.67). Features:

- Thrust vectoring (arrow keys) for tight maneuvers
- Working rudder (F7/F8) for course fine-tuning
- Can tow other boats (F11/F12 for tug rope, click-&-drag to position end of rope, L to lock on)
- Searchlight (F9/F10 to rotate, N to switch on/off)
- Lights (Ctrl+1)
- Emergency beacons (M) on rescue boat version
- 2 different versions (rescue boat and civilian version without emergency beacons), 5 different skins
- Lots of ropables for all your lifting & loading needs
- Works with the skinzip system

UPDATE 1.1
It's safe to delete your old weasel folder and replace with the new one. Changes:
- Lowered center of gravity to achieve more stability and tweaked engine power to account for the changed handling
- Converted all textures to .dds, easing up a few FPS

If you want to release a mod of this boat, follow 2 simple rules:
- Credit the original author (or authors, if you're modding a mod)
- NO conflicts with the original version! Change all material names, mesh names, texture names, give it an all-new UID and GUID.

If you just want to make a skin for the Weasel, make a *.skinzip. After all, that's precisely what the system was designed for. The good news is you won't have to worry about conflicts with the original.

Have fun!
Redeye