#!/usr/bin/env python3
"""
Example usage of the enhanced truck2jbeam converter

This script demonstrates various ways to use the truck2jbeam converter
programmatically and provides examples of common use cases.
"""

import os
import tempfile
from pathlib import Path

from rig import Rig
from config import get_config, ConversionSettings
import truck2jbeam


def create_sample_truck_file() -> str:
    """Create a sample truck file for demonstration"""
    truck_content = """Sample Truck
; This is a simple truck file for demonstration

globals
2000, 1000

nodes
; id,  x,    y,    z,   options
1,     0.0,  0.0,  0.0, l
2,     2.0,  0.0,  0.0, l
3,     1.0,  0.0,  1.0, l
4,     0.0,  1.0,  0.0, l
5,     2.0,  1.0,  0.0, l
6,     1.0,  1.0,  1.0, l

beams
; node1, node2, options
1, 2
1, 3
1, 4
2, 3
2, 5
3, 4
3, 5
3, 6
4, 5
4, 6
5, 6

wheels
; radius, width, rays, n1, n2, snode, braked, propulsed, arm, mass, spring, damp
0.5, 0.3, 12, 1, 4, 9999, 1, 1, 2, 50, 800000, 4000
0.5, 0.3, 12, 2, 5, 9999, 1, 1, 3, 50, 800000, 4000

engine
1000, 3000, 200, 3.5, -3.0, 1.0, 2.5, 4.0

brakes
5000

end
"""
    
    # Create temporary file
    with tempfile.NamedTemporaryFile(mode='w', suffix='.truck', delete=False) as f:
        f.write(truck_content)
        return f.name


def example_basic_conversion():
    """Example 1: Basic file conversion"""
    print("Example 1: Basic Conversion")
    print("=" * 40)
    
    # Create sample file
    truck_file = create_sample_truck_file()
    
    try:
        # Create rig instance and parse file
        rig = Rig()
        rig.from_file(truck_file)
        
        # Calculate masses
        rig.calculate_masses()
        
        # Get statistics
        stats = rig.get_statistics()
        print(f"Loaded truck: {rig.name}")
        print(f"Nodes: {stats['nodes']}")
        print(f"Beams: {stats['beams']}")
        print(f"Wheels: {stats['wheels']}")
        print(f"Total beam length: {stats['total_beam_length']:.2f}")
        
        # Convert to JBeam
        output_file = truck_file.replace('.truck', '.jbeam')
        rig.to_jbeam(output_file)
        
        print(f"Converted to: {output_file}")
        print(f"Output file size: {os.path.getsize(output_file)} bytes")
        
    finally:
        # Cleanup
        if os.path.exists(truck_file):
            os.unlink(truck_file)
        output_file = truck_file.replace('.truck', '.jbeam')
        if os.path.exists(output_file):
            os.unlink(output_file)
    
    print()


def example_with_validation():
    """Example 2: Conversion with validation"""
    print("Example 2: Conversion with Validation")
    print("=" * 40)
    
    truck_file = create_sample_truck_file()
    
    try:
        rig = Rig()
        rig.from_file(truck_file)
        
        # Validate the rig
        is_valid = rig.validate()
        print(f"Validation result: {'PASS' if is_valid else 'FAIL'}")
        
        if rig.parse_warnings:
            print(f"Warnings ({len(rig.parse_warnings)}):")
            for warning in rig.parse_warnings:
                print(f"  - {warning}")
        
        if rig.parse_errors:
            print(f"Errors ({len(rig.parse_errors)}):")
            for error in rig.parse_errors:
                print(f"  - {error}")
        
        # Calculate masses with validation
        rig.calculate_masses()
        
        # Show mass distribution
        print("\nNode masses:")
        for node in rig.nodes[:5]:  # Show first 5 nodes
            print(f"  {node.name}: {node.mass:.2f} kg")
        
        total_mass = sum(n.mass for n in rig.nodes)
        print(f"Total mass: {total_mass:.2f} kg")
        
    finally:
        if os.path.exists(truck_file):
            os.unlink(truck_file)
    
    print()


def example_with_configuration():
    """Example 3: Using configuration and templates"""
    print("Example 3: Configuration and Templates")
    print("=" * 40)
    
    # Get configuration manager
    config = get_config()
    
    # Show available templates
    templates = config.list_templates()
    print("Available templates:")
    for name, description in templates.items():
        print(f"  {name}: {description}")
    
    # Apply car template
    print("\nApplying car template...")
    config.apply_template("car")
    
    # Show current settings
    settings = config.settings
    print(f"Minimum mass: {settings.minimum_mass}")
    print(f"Default author: {settings.default_author}")
    print(f"Pretty print: {settings.pretty_print}")
    
    # Create custom settings
    custom_settings = ConversionSettings()
    custom_settings.minimum_mass = 15.0
    custom_settings.default_author = "Example User"
    custom_settings.pretty_print = True
    
    print(f"\nCustom settings:")
    print(f"Minimum mass: {custom_settings.minimum_mass}")
    print(f"Default author: {custom_settings.default_author}")
    
    print()


def example_error_handling():
    """Example 4: Error handling"""
    print("Example 4: Error Handling")
    print("=" * 40)
    
    # Create a truck file with errors
    bad_truck_content = """Bad Truck
nodes
1, 0.0, 0.0, 0.0, l
2, 1.0, 0.0, 0.0, l

beams
1, 2
1, 999  ; This beam references a non-existent node
2, 888  ; This one too

globals
-100, -50  ; Negative weights

end
"""
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.truck', delete=False) as f:
        f.write(bad_truck_content)
        truck_file = f.name
    
    try:
        rig = Rig()
        rig.from_file(truck_file)
        
        # Validation will catch the errors
        is_valid = rig.validate()
        print(f"Validation result: {'PASS' if is_valid else 'FAIL'}")
        
        print(f"\nFound {len(rig.parse_warnings)} warnings:")
        for warning in rig.parse_warnings:
            print(f"  - {warning}")
        
        print(f"\nFound {len(rig.parse_errors)} errors:")
        for error in rig.parse_errors:
            print(f"  - {error}")
        
        # Try to calculate masses anyway
        rig.calculate_masses()
        
        # Show statistics
        stats = rig.get_statistics()
        print(f"\nStatistics:")
        print(f"  Nodes: {stats['nodes']}")
        print(f"  Beams: {stats['beams']}")
        print(f"  Warnings: {stats['warnings']}")
        print(f"  Errors: {stats['errors']}")
        
    finally:
        if os.path.exists(truck_file):
            os.unlink(truck_file)
    
    print()


def example_batch_processing():
    """Example 5: Batch processing simulation"""
    print("Example 5: Batch Processing Simulation")
    print("=" * 40)
    
    # Create multiple sample files
    temp_dir = tempfile.mkdtemp()
    truck_files = []
    
    try:
        # Create 3 sample truck files
        for i in range(3):
            content = f"""Sample Truck {i+1}
globals
{1000 + i*500}, {500 + i*200}

nodes
1, 0.0, 0.0, 0.0, l
2, {1.0 + i*0.5}, 0.0, 0.0, l

beams
1, 2

end
"""
            truck_file = os.path.join(temp_dir, f"truck_{i+1}.truck")
            with open(truck_file, 'w') as f:
                f.write(content)
            truck_files.append(truck_file)
        
        print(f"Created {len(truck_files)} sample truck files")
        
        # Process each file
        results = []
        for truck_file in truck_files:
            try:
                rig = Rig()
                rig.from_file(truck_file)
                rig.calculate_masses()
                
                # Validate
                is_valid = rig.validate()
                
                # Get statistics
                stats = rig.get_statistics()
                
                results.append({
                    'file': os.path.basename(truck_file),
                    'name': rig.name,
                    'valid': is_valid,
                    'nodes': stats['nodes'],
                    'beams': stats['beams'],
                    'warnings': stats['warnings'],
                    'errors': stats['errors']
                })
                
                print(f"  ✓ Processed {os.path.basename(truck_file)}")
                
            except Exception as e:
                print(f"  ✗ Failed to process {os.path.basename(truck_file)}: {e}")
        
        # Summary
        print(f"\nBatch Processing Summary:")
        print(f"Files processed: {len(results)}")
        valid_files = sum(1 for r in results if r['valid'])
        print(f"Valid files: {valid_files}")
        total_warnings = sum(r['warnings'] for r in results)
        total_errors = sum(r['errors'] for r in results)
        print(f"Total warnings: {total_warnings}")
        print(f"Total errors: {total_errors}")
        
    finally:
        # Cleanup
        import shutil
        shutil.rmtree(temp_dir)
    
    print()


def main():
    """Run all examples"""
    print("truck2jbeam Enhanced Converter - Usage Examples")
    print("=" * 60)
    print()
    
    # Run examples
    example_basic_conversion()
    example_with_validation()
    example_with_configuration()
    example_error_handling()
    example_batch_processing()
    
    print("All examples completed!")
    print("\nFor more information, see:")
    print("  - README.md for comprehensive documentation")
    print("  - python truck2jbeam.py --help for CLI options")
    print("  - python truck2jbeam_config.py --help for configuration")
    print("  - python test_truck2jbeam.py to run tests")


if __name__ == "__main__":
    main()
