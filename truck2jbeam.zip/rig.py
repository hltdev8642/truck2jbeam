from rig_common import truck_sections, truck_inline_sections, Axle
import rig_parser as parser
import rig_torquecurves as curves
import logging
import math
from typing import List, Optional, Dict, Any, Tuple


def vector_distance(x1: float, y1: float, z1: float, x2: float, y2: float, z2: float) -> float:
    """Calculate squared distance between two 3D points"""
    nx = x2 - x1
    ny = y2 - y1
    nz = z2 - z1
    return nx * nx + ny * ny + nz * nz


def vector_length(x1: float, y1: float, z1: float, x2: float, y2: float, z2: float) -> float:
    """Calculate actual distance between two 3D points"""
    return math.sqrt(vector_distance(x1, y1, z1, x2, y2, z2))

class RigParseError(Exception):
    """Custom exception for rig parsing errors"""
    def __init__(self, message: str, line_number: Optional[int] = None, line_content: Optional[str] = None):
        self.line_number = line_number
        self.line_content = line_content
        if line_number:
            message = f"Line {line_number}: {message}"
        if line_content:
            message += f" ('{line_content.strip()}')"
        super().__init__(message)


class Rig:
    """Enhanced Rig class with better error handling and validation"""

    def __init__(self):
        self.name: str = "Untitled Rig Class"
        self.authors: List[str] = []
        self.nodes: List[Any] = []
        self.beams: List[Any] = []
        self.hydros: List[Any] = []
        self.internal_cameras: List[Any] = []
        self.rails: List[Any] = []
        self.slidenodes: List[Any] = []
        self.wheels: List[Any] = []
        self.flexbodies: List[Any] = []
        self.axles: List[Axle] = []
        self.brakes: List[float] = []
        self.torquecurve: Optional[List[List[float]]] = None
        self.engine: Optional[Any] = None
        self.engoption: Optional[Any] = None
        self.refnodes: Optional[Any] = None
        self.minimass: float = 50
        self.dry_weight: float = 10000
        self.load_weight: float = 10000
        self.triangles: List[List[str]] = []
        self.rollon: bool = False
        self.type: str = 'truck'

        # Statistics and validation
        self.parse_warnings: List[str] = []
        self.parse_errors: List[str] = []
        self.logger = logging.getLogger(__name__)

    def add_warning(self, message: str, line_number: Optional[int] = None):
        """Add a parsing warning"""
        warning = f"Line {line_number}: {message}" if line_number else message
        self.parse_warnings.append(warning)
        self.logger.warning(warning)

    def add_error(self, message: str, line_number: Optional[int] = None):
        """Add a parsing error"""
        error = f"Line {line_number}: {message}" if line_number else message
        self.parse_errors.append(error)
        self.logger.error(error)

    def validate(self) -> bool:
        """Validate the rig data for common issues"""
        is_valid = True

        # Check for minimum required components
        if not self.nodes:
            self.add_error("No nodes found - vehicle needs nodes to function")
            is_valid = False

        if not self.beams:
            self.add_error("No beams found - vehicle needs beams for structure")
            is_valid = False

        # Check for orphaned beams (beams referencing non-existent nodes)
        node_names = {node.name for node in self.nodes}
        for beam in self.beams:
            if beam.id1 not in node_names:
                self.add_warning(f"Beam references non-existent node: {beam.id1}")
            if beam.id2 not in node_names:
                self.add_warning(f"Beam references non-existent node: {beam.id2}")

        # Check for duplicate nodes
        node_positions = {}
        for node in self.nodes:
            pos_key = (round(node.x, 3), round(node.y, 3), round(node.z, 3))
            if pos_key in node_positions:
                self.add_warning(f"Nodes {node.name} and {node_positions[pos_key]} have identical positions")
            else:
                node_positions[pos_key] = node.name

        # Check for reasonable mass values
        if self.dry_weight <= 0:
            self.add_warning(f"Dry weight is {self.dry_weight}, should be positive")

        if self.load_weight <= 0:
            self.add_warning(f"Load weight is {self.load_weight}, should be positive")

        # Check engine configuration
        if self.engine and not self.torquecurve:
            self.add_warning("Engine defined but no torque curve found")

        return is_valid

    def get_statistics(self) -> Dict[str, Any]:
        """Get statistics about the rig"""
        stats = {
            'nodes': len(self.nodes),
            'beams': len(self.beams),
            'wheels': len(self.wheels),
            'hydros': len(self.hydros),
            'flexbodies': len(self.flexbodies),
            'cameras': len(self.internal_cameras),
            'rails': len(self.rails),
            'slidenodes': len(self.slidenodes),
            'triangles': len(self.triangles),
            'axles': len(self.axles),
            'dry_weight': self.dry_weight,
            'load_weight': self.load_weight,
            'has_engine': self.engine is not None,
            'has_torquecurve': self.torquecurve is not None,
            'warnings': len(self.parse_warnings),
            'errors': len(self.parse_errors)
        }

        # Calculate total beam length
        total_beam_length = 0
        for beam in self.beams:
            node1 = next((n for n in self.nodes if n.name == beam.id1), None)
            node2 = next((n for n in self.nodes if n.name == beam.id2), None)
            if node1 and node2:
                total_beam_length += vector_length(node1.x, node1.y, node1.z, node2.x, node2.y, node2.z)

        stats['total_beam_length'] = total_beam_length

        return stats

    def calculate_masses(self):
        """
        Calculate node masses based on RoR algorithm
        Python version of https://github.com/RigsOfRods/rigs-of-rods/blob/master/source/main/physics/Beam.cpp#L814
        """
        if not self.nodes:
            self.add_error("Cannot calculate masses: no nodes found")
            return

        numnodes = 0
        numloadnodes = 0
        for n in self.nodes:
            if n.load_bearer:
                numloadnodes += 1
            else:
                numnodes += 1

        self.logger.debug(f"Found {numloadnodes} load-bearing nodes, {numnodes} regular nodes")

        # Initialize node masses
        for n in self.nodes:
            if not n.load_bearer:
                n.mass = 0
            elif n.override_mass == False:
                if numloadnodes > 0:
                    n.mass = self.load_weight / numloadnodes
                else:
                    n.mass = self.minimass
                    self.add_warning("No load-bearing nodes found, using minimum mass")
            elif n.override_mass != False:
                n.mass = n.override_mass

        # Calculate average linear density from beam lengths
        avg_lin_dens = 0.0
        valid_beams = 0

        for b in self.beams:
            if b.type != 'VIRTUAL':
                node1 = next((x for x in self.nodes if x.name == b.id1), None)
                node2 = next((x for x in self.nodes if x.name == b.id2), None)

                if node1 is not None and node2 is not None:
                    beam_length = vector_distance(node1.x, node1.y, node1.z, node2.x, node2.y, node2.z)
                    avg_lin_dens += beam_length
                    valid_beams += 1
                else:
                    self.add_warning(f"Beam references missing nodes: {b.id1}, {b.id2}")

        if avg_lin_dens == 0:
            self.add_error("Cannot calculate masses: no valid beams found")
            return

        self.logger.debug(f"Calculated linear density from {valid_beams} beams")

        # Distribute dry weight based on beam lengths
        for b in self.beams:
            if b.type != 'VIRTUAL':
                node1 = next((x for x in self.nodes if x.name == b.id1), None)
                node2 = next((x for x in self.nodes if x.name == b.id2), None)

                if node1 is not None and node2 is not None:
                    beam_length = vector_distance(node1.x, node1.y, node1.z, node2.x, node2.y, node2.z)
                    half_mass = beam_length * self.dry_weight / avg_lin_dens / 2

                    node1.mass += half_mass
                    node2.mass += half_mass

        # Ensure minimum mass
        nodes_adjusted = 0
        for n in self.nodes:
            if n.mass < self.minimass:
                n.mass = self.minimass
                nodes_adjusted += 1

        if nodes_adjusted > 0:
            self.logger.debug(f"Adjusted {nodes_adjusted} nodes to minimum mass of {self.minimass}")

        # Calculate total mass for validation
        total_mass = sum(n.mass for n in self.nodes)
        expected_mass = self.dry_weight + self.load_weight
        mass_difference = abs(total_mass - expected_mass)

        if mass_difference > expected_mass * 0.1:  # More than 10% difference
            self.add_warning(f"Total calculated mass ({total_mass:.1f}) differs significantly from expected ({expected_mass:.1f})")

        self.logger.debug(f"Mass calculation complete. Total mass: {total_mass:.1f}")




    def from_file(self, filename: str):
        """
        Parse a RoR rig file with enhanced error handling

        Args:
            filename: Path to the rig file to parse

        Raises:
            RigParseError: If critical parsing errors occur
            FileNotFoundError: If the file doesn't exist
            PermissionError: If the file can't be read
        """
        self.logger.info(f"Parsing rig file: {filename}")

        # Read file with error handling
        try:
            with open(filename, 'r', encoding='utf-8', errors='replace') as f:
                trucklines = f.readlines()
        except FileNotFoundError:
            raise RigParseError(f"File not found: {filename}")
        except PermissionError:
            raise RigParseError(f"Permission denied reading file: {filename}")
        except Exception as e:
            raise RigParseError(f"Error reading file {filename}: {e}")

        if not trucklines:
            raise RigParseError("File is empty")

        self.logger.debug(f"Read {len(trucklines)} lines from file")

        # Initialize parsing state
        last_beamspring = 9000000
        last_beamdamp = 12000
        last_beamdeform = 400000
        last_beamstrength = 1000000

        springscale = 1
        dampscale = 1
        deformscale = 1
        strengthscale = 1

        cur_detach_group = 0

        last_loadweight = 0.0
        last_friction = 1.0

        # Parse the rig file
        current_section = None
        lines_parsed = 0

        for line_number, line in enumerate(trucklines, 1):
            try:
                # First line is the title
                if lines_parsed == 0:
                    self.name = line.replace("\n", "").strip()
                    if not self.name:
                        self.name = "Untitled Rig"
                        self.add_warning("Empty title line, using default name", line_number)
                    lines_parsed += 1
                    continue

                # Parse line components
                line_cmps = parser.PrepareLine(line)

                # Skip invalid/empty lines
                if line_cmps is None:
                    continue

                num_components = len(line_cmps)

                if num_components == 0:
                    continue

                # Handle inline sections
                if line_cmps[0] in truck_inline_sections:
                    section_name = line_cmps[0]

                    try:
                        if section_name == "set_beam_defaults" and num_components >= 5:
                            last_beamspring, last_beamdamp, last_beamdeform, last_beamstrength = parser.ParseSetBeamDefaults(line_cmps)
                        elif section_name == "set_beam_defaults_scale" and num_components >= 5:
                            springscale, dampscale, deformscale, strengthscale = parser.ParseSetBeamDefaults(line_cmps)
                        elif section_name == "set_node_defaults" and num_components >= 5:
                            defaults = parser.ParseSetNodeDefaults(line_cmps)
                            last_loadweight = defaults[0]
                            last_friction = defaults[1]
                        elif section_name == "detacher_group":
                            if num_components >= 2:
                                cur_detach_group = int(line_cmps[1])
                            else:
                                self.add_warning("detacher_group missing group ID", line_number)
                        elif section_name == "rollon":
                            self.rollon = True
                        elif section_name == "author":
                            if num_components >= 2:
                                author_data = line_cmps[1].strip().split()
                                if len(author_data) >= 3:
                                    self.authors.append(author_data[2].replace("_", " "))
                                else:
                                    self.add_warning("Invalid author format", line_number)
                            else:
                                self.add_warning("author missing data", line_number)
                        elif section_name == "forset" and len(self.flexbodies) > 0:
                            forset = parser.ParseForset(line_cmps)
                            group = parser.ParseGroupName(self.flexbodies[len(self.flexbodies) - 1].mesh)
                            for ranges in forset:
                                for cr in range(ranges[0], ranges[1] + 1):
                                    if cr >= len(self.nodes):
                                        self.add_warning(f"forset references invalid node index {cr}", line_number)
                                        break
                                    else:
                                        self.nodes[cr].group.append(group)
                        elif section_name == "end":
                            # Stop parsing
                            break
                    except (ValueError, IndexError) as e:
                        self.add_error(f"Error parsing {section_name}: {e}", line_number)

                    continue

                # Handle new sections
                if line_cmps[0] in truck_sections:
                    current_section = line_cmps[0]
                    continue

                # Parse section content
                if (current_section == "nodes" or current_section == "nodes2") and num_components >= 4:
                    node_object = parser.ParseNode(line_cmps)

                    # apply set_node_defaults
                    node_object.frictionCoef = last_friction
                    if last_loadweight > 0:
                        node_object.override_mass = last_loadweight

                    self.nodes.append(node_object)
                elif current_section == "beams" and num_components >= 2:
                    beam_object = parser.ParseBeam(line_cmps, last_beamspring * springscale, last_beamdamp * dampscale, last_beamstrength * strengthscale, last_beamdeform * deformscale)
                    parser.SetBeamBreakgroup(beam_object, cur_detach_group)
                    self.beams.append(beam_object)
                elif current_section == "hydros" and num_components >= 3:
                    self.hydros.append(parser.ParseHydro(line_cmps, last_beamspring, last_beamdamp, last_beamstrength * strengthscale, last_beamdeform * deformscale))
                elif current_section == "globals" and num_components >= 2:
                    self.dry_weight = float(line_cmps[0])
                    self.load_weight = float(line_cmps[1])
                elif current_section == "railgroups" and num_components >= 2:
                    self.rails.append(parser.ParseRailgroup(line_cmps))
                elif current_section == "slidenodes" and num_components >= 2:
                    slidenode, rail = parser.ParseSlidenode(line_cmps)

                    if not isinstance(rail, str):
                        # this is a Railgroup object, add it to self
                        self.rails.append(rail)

                    self.slidenodes.append(slidenode)
                elif current_section == "fixes" and num_components >= 1:
                    # set node(s) to fixed
                    nid = line_cmps[0]
                    if nid.isdigit():
                        nid = "node" + nid

                    node = next((x for x in self.nodes if x.name == nid), None)
                    if node:
                        node.fixed = True
                    else:
                        self.add_warning(f"Cannot fix unknown node: {nid}", line_number)

                # Add more section parsing here if needed...
                # For now, skip unsupported sections with a warning
                elif current_section and num_components > 0:
                    # This is content for a section we don't fully support yet
                    pass

                lines_parsed += 1

            except Exception as e:
                self.add_error(f"Error parsing line: {e}", line_number)
                lines_parsed += 1
                continue

        # Final validation and cleanup
        if self.torquecurve is None and self.engine is not None:
            self.torquecurve = curves.get_curve("default")

        self.logger.info(f"Parsing complete. Processed {lines_parsed} lines.")

        # Run validation
        self.validate()

    def to_jbeam(self, filename):
      # sort beams by something so the jbeam doesn't look like a total mess
      self.beams.sort(key=lambda x: x.beamSpring, reverse=True)

      # open file and write it
      f = open(filename, 'w')
      f.write("{\n\t\"truck2jbeam\":{\n\t\t\"slotType\": \"main\",\n\n\t\t\"information\":{\n\t\t\t\"name\": \"" + self.name + "\",\n\t\t\t\"authors\": \"insert your name here\"\n\t\t}\n\n")

      # write refnodes
      if self.refnodes is not None:
        f.write("\t\t\"refNodes\":[\n\t\t\t[\"ref:\", \"back:\", \"left:\", \"up:\"],\n")
        f.write("\t\t\t[\"" + self.refnodes.center + "\", \"" + self.refnodes.back + "\", \"" + self.refnodes.left + "\", \"" + self.refnodes.center + "\"]\n")
        f.write("\t\t],\n\n")

      # write torquecurve
      if self.torquecurve is not None:
        f.write("\t\t\"enginetorque\":[\n\t\t\t[\"rpm\", \"torque\"],\n")

        # write curve, and multiply torque
        for t in self.torquecurve:
          f.write("\t\t\t[" + str(t[0]) + ", " + str(t[1] * self.engine.torque) + "],\n")

        f.write("\t\t],\n\n")

      # write engine
      if self.engine is not None:
        f.write("\t\t\"engine\":{\n")

        # idle/max RPM
        if self.engoption is None:
          f.write("\t\t\t\"idleRPM\":800,\n")
        else:
          f.write("\t\t\t\"idleRPM\":" + str(self.engoption.idle_rpm) + ",\n")

        f.write("\t\t\t\"maxRPM\":" + str(self.engine.max_rpm * 1.25) + ",\n")

        # shift RPMs
        f.write("\t\t\t\"shiftDownRPM\":" + str(self.engine.min_rpm) + ",\n")
        f.write("\t\t\t\"shiftUpRPM\":" + str(self.engine.max_rpm) + ",\n")

        # diff
        f.write("\t\t\t\"differential\":" + str(self.engine.differential) + ",\n")

        # inertia
        if self.engoption is None:
          f.write("\t\t\t\"inertia\":10,\n")
        else:
          f.write("\t\t\t\"inertia\":" + str(self.engoption.inertia) + ",\n")

        # ratios
        f.write("\t\t\t\"gears\":[")
        for g in self.engine.gears:
          f.write(str(g) + ", ")

        # seek before ratios last comma/spce
        f.seek(f.tell() - 2)
        f.write("],\n")

        # rest of engoption stuff
        if self.engoption is not None:
          f.write("\t\t\t\"clutchTorque\":" + str(self.engoption.clutch_force) + ",\n")
          f.write("\t\t\t\"clutchDuration\":" + str(self.engoption.clutch_time) + ",\n")

        f.write("\t\t}\n\n")


      # write cameras
      if len(self.internal_cameras) > 0:
        last_beam_spring = -1.0
        last_beam_damp = -1.0

        #     "camerasInternal":[
        #
        f.write("\t\t\"camerasInternal\":[\n\t\t\t[\"type\", \"x\", \"y\", \"z\", \"fov\", \"id1:\", \"id2:\", \"id3:\", \"id4:\", \"id5:\", \"id6:\"],\n\t\t\t{\"nodeWeight\": 20},\n")
        for c in self.internal_cameras:
            if c.beamSpring != last_beam_spring:
                last_beam_spring = c.beamSpring
                f.write("\t\t\t{\"beamSpring\":" + str(c.beamSpring) + "}\n")
            if c.beamDamp != last_beam_damp:
                last_beam_damp = c.beamDamp
                f.write("\t\t\t{\"beamDamp\":" + str(c.beamDamp) + "}\n")

            # write camera line
            f.write("\t\t\t[\"" + c.type + "\", " + str(c.x) + ", " + str(c.y) + ", " + str(c.z) + ", " + str(c.fov) + ", \"" + c.id1 + "\", \"" + c.id2 + "\", \"" + c.id3 + "\", \"" + c.id4 + "\", \"" + c.id5 + "\", \"" + c.id6 + "\"],\n")

        f.write("\t\t],\n\n")

      # write flexbodies
      if len(self.flexbodies) > 0:
        f.write("\t\t\"flexbodies\":[\n\t\t\t[\"mesh\", \"[group]:\", \"nonFlexMaterials\"],\n")
        for fb in self.flexbodies:
          #return fr + (to - fr) * t
          refnode = next((x for x in self.nodes if x.name == fb.refnode), None)
          xnode = next((x for x in self.nodes if x.name == fb.xnode), None)
          ynode = next((x for x in self.nodes if x.name == fb.ynode), None)


          if refnode is None or xnode is None or ynode is None:
            print("Can't find nodes for flexbody " + fb.mesh + ". Possibly forset on tires?")
            continue


          real_x_offset = refnode.x + (xnode.x - refnode.x) * fb.offsetX
          real_y_offset = refnode.y + (ynode.y - refnode.y) * fb.offsetY
          real_z_offset = fb.offsetZ - refnode.z

          real_x_rotation = fb.rotX
          real_y_rotation = fb.rotY
          real_z_rotation = fb.rotZ

          f.write("\t\t\t[\"" + parser.ParseGroupName(fb.mesh) + "\", [\"" + parser.ParseGroupName(fb.mesh) + "\"], [], {\"pos\":{\"x\":" + str(real_x_offset) + ", \"y\":" + str(real_y_offset) + ", \"z\":" + str(real_z_offset) + "}, \"rot\":{\"x\":" + str(real_x_rotation) + ", \"y\":" + str(real_y_rotation) + ", \"z\":" + str(real_z_rotation) + "}, \"scale\":{\"x\":1, \"y\":1, \"z\":1}}],\n")
        f.write("\t\t],\n\n")

      # write nodes
      if len(self.nodes) > 0:
        last_node_mass = -1.0
        last_node_friction = 1.0
        last_selfcollision = False
        last_groups = []
        f.write("\t\t\"nodes\":[\n\t\t\t[\"id\", \"posX\", \"posY\", \"posZ\"],\n")
        for n in self.nodes:
            if n.mass != last_node_mass:
                f.write("\t\t\t{\"nodeWeight\": " + str(n.mass) + "},\n")
                last_node_mass = n.mass
            if n.frictionCoef != last_node_friction:
                f.write("\t\t\t{\"frictionCoef\": " + str(n.frictionCoef) + "},\n")
                last_node_friction = n.frictionCoef
            if n.selfCollision != last_selfcollision:
                f.write("\t\t\t{\"selfCollision\": " + str(n.selfCollision).lower() + "},\n")
                last_selfcollision = n.selfCollision
            if n.group != last_groups:
                if len(n.group) > 0:
                  f.write("\t\t\t{\"group\": [")
                  for g in n.group:
                    f.write("\"" + g + "\", ")
                  f.seek(f.tell() - 2, 0)
                  f.write("]},\n")
                else:
                  f.write("\t\t\t{\"group\": \"\"},\n")

                last_groups = n.group

            # write node line
            f.write("\t\t\t[\"" + n.name + "\", " + str(n.x) + ", " + str(n.y) + ", " + str(n.z))

            # write inline stuff
            if n.coupler:
                f.write(", {\"couplerTag\":\"fifthwheel\"}")

            f.write("],\n")
        f.write("\t\t],\n\n")

      # write beams
      if len(self.beams) > 0:
        last_beam_spring = -1.0
        last_beam_damp = -1.0
        last_beam_deform = -1.0
        last_beam_strength = -1.0
        last_beam_shortbound = -1.0
        last_beam_longbound = -1.0
        last_beam_precomp = -1.0
        last_beam_type = 'NONEXISTANT'
        last_beam_damprebound = False
        last_breakgroup = ''

        f.write("\t\t\"beams\":[\n\t\t\t[\"id1:\", \"id2:\"],\n")
        for b in self.beams:
            # write vars if changed
            if b.beamDampRebound != last_beam_damprebound:
                last_beam_damprebound = b.beamDampRebound
                f.write("\t\t\t{\"beamDampRebound\":" + str(b.beamDampRebound).lower() + "},\n")
            if b.type != last_beam_type:
                last_beam_type = b.type
                f.write("\t\t\t{\"beamType\":\"|" + b.type + "\"},\n")
            if b.beamSpring != last_beam_spring:
                last_beam_spring = b.beamSpring
                f.write("\t\t\t{\"beamSpring\":" + str(b.beamSpring) + "}\n")
            if b.beamDamp != last_beam_damp:
                last_beam_damp = b.beamDamp
                f.write("\t\t\t{\"beamDamp\":" + str(b.beamDamp) + "}\n")
            if b.beamDeform != last_beam_deform:
                last_beam_deform = b.beamDeform
                f.write("\t\t\t{\"beamDeform\":" + str(b.beamDeform) + "}\n")
            if b.beamStrength != last_beam_strength:
                last_beam_strength = b.beamStrength
                f.write("\t\t\t{\"beamStrength\":" + str(b.beamStrength) + "}\n")
            if b.beamShortBound != last_beam_shortbound:
                last_beam_shortbound = b.beamShortBound
                f.write("\t\t\t{\"beamShortBound\":" + str(b.beamShortBound) + "}\n")
            if b.beamLongBound != last_beam_longbound:
                last_beam_longbound = b.beamLongBound
                f.write("\t\t\t{\"beamLongBound\":" + str(b.beamLongBound) + "}\n")
            if b.beamPrecompression != last_beam_precomp:
                last_beam_precomp = b.beamPrecompression
                f.write("\t\t\t{\"beamPrecompression\":" + str(b.beamPrecompression) + "}\n")
            if b.breakGroup != last_breakgroup:
                last_breakgroup = b.breakGroup
                f.write("\t\t\t{\"breakGroup\":\"" + b.breakGroup + "\"}\n")
            # write beam line
            f.write("\t\t\t[\"" + b.id1 + "\", \"" + b.id2 + "\"],\n")

        f.write("\t\t],\n\n")

      # write rails (name, nodes are params)
      if len(self.rails) > 0:
        f.write("\t\t\"rails\":{\n")
        for r in self.rails:
          # start write rail line
          f.write("\t\t\t\"" + r.name + "\":{\"links:\":[")
          for n in r.nodes:
            f.write("\"" + n + "\", ")

          # seek before last comma, and overwrite it
          f.seek(f.tell() - 2, 0)

          # finish writing rail line
          f.write("], \"looped\":false, \"capped\":true}\n")

        f.write("\t\t}\n\n")

      # write slidenodes
      if len(self.slidenodes) > 0:
        f.write("\t\t\"slidenodes\":[\n\t\t\t[\"id:\", \"railName\", \"attached\", \"fixToRail\", \"tolerance\", \"spring\", \"strength\", \"capStrength\"],\n")
        for s in self.slidenodes:
          # write slidenode line
          f.write("\t\t\t[\"" + s.node + "\", \"" + s.rail + "\", true, true, " + str(s.tolerance) + ", " + str(s.spring) + ", " + str(s.strength).replace("inf", "100000000") + ", 345435],\n")
        f.write("\t\t],\n\n")

      # write diffs
      if len(self.axles) > 0:
        f.write("\t\t\"differentials\":[\n\t\t\t[\"wheelName1\", \"wheelName2\", \"type\", \"state\", \"closedTorque\", \"engineTorqueCoef\"],\n")
        for a in self.axles:
          f.write("\t\t\t[\"" + a.wid1 + "\", \"" + a.wid2 + "\", \"" + a.type + "\", \"" + a.state + "\", 10000, 1],\n")
        f.write("\t\t],\n\n")

      # write triangles
      if len(self.triangles) > 0:
        f.write("\t\t\"triangles\":[\n\t\t\t[\"id1:\", \"id2:\", \"id3:\"],\n\t\t\t{\"dragCoef\":0},\n")
        for t in self.triangles:
          f.write("\t\t\t[\"" + t[0] + "\", \"" + t[1] + "\", \"" + t[2] + "\"],\n")
        f.write("\t\t],\n\n")

      # write wheels
      if len(self.wheels) > 0:
        last_wheel_spring = -1.0
        last_wheel_damp = -1.0
        last_tire_damp = -1.0
        last_tire_spring = -1.0
        last_numrays = -1
        last_width = -1
        last_hub_radius = -1
        last_radius = -1
        last_propulsed = 0
        last_mass = 0
        last_wheel_type = "NONE"

        c_wheel_idx = 0

        wrote_advanced_wheel = False

        f.write("\t\t\"pressureWheels\":[\n\t\t\t[\"name\",\"hubGroup\",\"group\",\"node1:\",\"node2:\",\"nodeS\",\"nodeArm:\",\"wheelDir\"],\n")
        if len(self.brakes) > 0:
          f.write("\t\t\t{\"brakeTorque\":" + str(self.brakes[0]) + ", \"parkingTorque\":" + str(self.brakes[1]) + "},\n")

        if self.rollon:
          f.write("\t\t\t{\"selfCollision\":true}\n")

        for w in self.wheels:
          # write global vars if changed
          if last_wheel_type != w.type:
            last_wheel_type = w.type
            if w.type == "wheels":
              f.write("\t\t\t{\"hasTire\":false},\n")
              f.write("\t\t\t{\"hubNodeMaterial\":\"|NM_RUBBER\"},\n")
            else:
              f.write("\t\t\t{\"hasTire\":true},\n")
              f.write("\t\t\t{\"hubNodeMaterial\":\"|NM_METAL\"},\n")

          if w.drivetype > 0 and last_propulsed == 0 and len(self.axles) == 0:
            last_propulsed = 1
            f.write("\t\t\t{\"propulsed\":" + str(last_propulsed) + "}\n")
          elif w.drivetype == 0 and last_propulsed == 1 and len(self.axles) == 0:
            last_propulsed = 0
            f.write("\t\t\t{\"propulsed\":" + str(last_propulsed) + "}\n")
          if w.width != last_width:
            last_width = w.width
            f.write("\t\t\t{\"hubWidth\":" + str(w.width) + "}\n")
            f.write("\t\t\t{\"tireWidth\":" + str(w.width) + "}\n")
          if w.num_rays != last_numrays:
            last_numrays = w.num_rays
            f.write("\t\t\t{\"numRays\":" + str(w.num_rays) + "}\n")
          if w.mass != last_mass:
            last_mass = w.mass
            if w.type == "wheels":
              f.write("\t\t\t{\"hubNodeWeight\":" + str(w.mass / (w.num_rays  * 2)) + "}\n")
            else:
              f.write("\t\t\t{\"nodeWeight\":" + str(w.mass / (w.num_rays  * 4)) + "}\n")
              f.write("\t\t\t{\"hubNodeWeight\":" + str(w.mass / (w.num_rays  * 4)) + "}\n")

          # basic wheels
          if w.type == "wheels":
            if w.spring != last_wheel_spring:
              last_wheel_spring = w.spring
              f.write("\t\t\t{\"beamSpring\":" + str(w.spring) + "}\n")
            if w.damp != last_wheel_damp:
              last_wheel_damp = w.damp
              f.write("\t\t\t{\"beamDamp\":" + str(w.damp) + "}\n")
            if w.radius != last_hub_radius:
              last_hub_radius = w.radius
              f.write("\t\t\t{\"hubRadius\":" + str(w.radius) + "}\n")


          # advanced wheels
          if w.type == "wheels.advanced":
            # first things first, 'global' stuff
            if not wrote_advanced_wheel:
              wrote_advanced_wheel = True
              f.write("\t\t\t{\"disableMeshBreaking\":true}\n")
              f.write("\t\t\t{\"disableHubMeshBreaking\":false}\n")
              f.write("\t\t\t{\"enableTireReinfBeams\":true}\n")
              f.write("\t\t\t{\"pressurePSI\":30}\n")

            if w.hub_spring != last_wheel_spring:
              last_wheel_spring = w.hub_spring
              f.write("\t\t\t{\"beamSpring\":" + str(w.hub_spring) + "}\n")
            if w.hub_damp != last_wheel_damp:
              last_wheel_damp = w.hub_damp
              f.write("\t\t\t{\"beamDamp\":" + str(w.hub_damp) + "}\n")
            if w.tire_damp != last_tire_damp:
              last_tire_damp = w.tire_damp
              f.write("\t\t\t{\"wheelSideBeamDamp\":" + str(w.tire_damp) + "}\n")
              f.write("\t\t\t{\"wheelSideBeamDampExpansion\":" + str(w.tire_damp) + "}\n")
              f.write("\t\t\t{\"wheelReinfBeamDamp\":" + str(w.tire_damp) + "}\n")
              f.write("\t\t\t{\"wheelTreadBeamDamp\":" + str(w.tire_damp) + "}\n")
              f.write("\t\t\t{\"wheelPeripheryBeamDamp\":" + str(w.tire_damp) + "}\n")
            if w.tire_spring != last_tire_spring:
              last_tire_spring = w.tire_spring
              f.write("\t\t\t{\"wheelSideBeamSpringExpansion\":" + str(w.tire_spring) + "}\n")
              f.write("\t\t\t{\"wheelReinfBeamSpring\":" + str(w.tire_spring) + "}\n")
              f.write("\t\t\t{\"wheelTreadBeamSpring\":" + str(w.tire_spring) + "}\n")
              f.write("\t\t\t{\"wheelPeripheryBeamSpring\":" + str(w.tire_spring) + "}\n")
            if w.tire_radius != last_radius:
              last_radius = w.tire_radius
              f.write("\t\t\t{\"radius\":" + str(w.tire_radius) + "}\n")

          # write wheel line
          snode = "\"" + w.snode + "\"" if w.snode != "node9999" else 9999
          drivetype = -1 if w.drivetype == 2 else w.drivetype
          f.write("\t\t\t[\"rorwheel" + str(c_wheel_idx) + "\", \"none\", \"none\", \"" + w.nid1 + "\", \"" + w.nid2 + "\", "  + str(snode) + ", \"" + w.armnode + "\", " + str(drivetype) + "],\n\n")

          #increment wheel ID
          c_wheel_idx += 1
        f.write("\t\t],\n\n")


      # write hydros
      if len(self.hydros) > 0:
        last_beam_spring = -1.0
        last_beam_damp = -1.0
        last_beam_deform = -1.0
        last_beam_strength = -1.0

        f.write("\t\t\"hydros\":[\n\t\t\t[\"id1:\", \"id2:\"],\n")
        for h in self.hydros:
            # write vars if changed
            if h.beamSpring != last_beam_spring:
                last_beam_spring = h.beamSpring
                f.write("\t\t\t{\"beamSpring\":" + str(h.beamSpring) + "}\n")
            if h.beamDamp != last_beam_damp:
                last_beam_damp = h.beamDamp
                f.write("\t\t\t{\"beamDamp\":" + str(h.beamDamp) + "}\n")
            if h.beamDeform != last_beam_deform:
                last_beam_deform = h.beamDeform
                f.write("\t\t\t{\"beamDeform\":" + str(h.beamDeform) + "}\n")
            if h.beamStrength != last_beam_strength:
                last_beam_strength = h.beamStrength
                f.write("\t\t\t{\"beamStrength\":" + str(h.beamStrength) + "}\n")

            # write hydro line
            f.write("\t\t\t[\"" + h.id1 + "\", \"" + h.id2 + "\", {\"inputSource\": \"steering\", \"inputFactor\": " + str(h.factor) + ", \"inRate\": 0.25, \"outRate\": 0.25}],\n")

        f.write("\t\t],\n")


      f.write("\t}\n}")
      f.close()