#!/usr/bin/env python3
"""
Test suite for truck2jbeam converter

This module contains comprehensive tests for the truck2jbeam conversion
functionality, including unit tests and integration tests.
"""

import unittest
import tempfile
import os
import json
from pathlib import Path
from unittest.mock import patch, MagicMock

# Import modules to test
from rig import Rig, RigParseError, vector_distance, vector_length
from rig_common import Node, Beam, Engine
import rig_parser as parser
from config import ConversionSettings, ConfigManager


class TestVectorFunctions(unittest.TestCase):
    """Test vector calculation functions"""
    
    def test_vector_distance(self):
        """Test vector distance calculation"""
        # Test basic distance
        dist = vector_distance(0, 0, 0, 3, 4, 0)
        self.assertEqual(dist, 25)  # 3^2 + 4^2 = 25
        
        # Test 3D distance
        dist = vector_distance(0, 0, 0, 1, 1, 1)
        self.assertEqual(dist, 3)  # 1^2 + 1^2 + 1^2 = 3
        
        # Test negative coordinates
        dist = vector_distance(-1, -1, -1, 1, 1, 1)
        self.assertEqual(dist, 12)  # 2^2 + 2^2 + 2^2 = 12
    
    def test_vector_length(self):
        """Test vector length calculation"""
        # Test basic length
        length = vector_length(0, 0, 0, 3, 4, 0)
        self.assertEqual(length, 5.0)  # sqrt(25) = 5
        
        # Test 3D length
        length = vector_length(0, 0, 0, 1, 1, 1)
        self.assertAlmostEqual(length, 1.732, places=3)  # sqrt(3)


class TestRigClass(unittest.TestCase):
    """Test Rig class functionality"""
    
    def setUp(self):
        """Set up test fixtures"""
        self.rig = Rig()
    
    def test_initialization(self):
        """Test Rig initialization"""
        self.assertEqual(self.rig.name, "Untitled Rig Class")
        self.assertEqual(len(self.rig.nodes), 0)
        self.assertEqual(len(self.rig.beams), 0)
        self.assertEqual(self.rig.dry_weight, 10000)
        self.assertEqual(self.rig.load_weight, 10000)
        self.assertEqual(self.rig.minimass, 50)
    
    def test_add_warning(self):
        """Test warning addition"""
        self.rig.add_warning("Test warning", 10)
        self.assertEqual(len(self.rig.parse_warnings), 1)
        self.assertIn("Line 10", self.rig.parse_warnings[0])
    
    def test_add_error(self):
        """Test error addition"""
        self.rig.add_error("Test error", 5)
        self.assertEqual(len(self.rig.parse_errors), 1)
        self.assertIn("Line 5", self.rig.parse_errors[0])
    
    def test_validation_empty_rig(self):
        """Test validation of empty rig"""
        is_valid = self.rig.validate()
        self.assertFalse(is_valid)
        self.assertGreater(len(self.rig.parse_errors), 0)
    
    def test_validation_with_nodes_and_beams(self):
        """Test validation with basic components"""
        # Add some test nodes
        node1 = Node("node1", 0, 0, 0)
        node2 = Node("node2", 1, 0, 0)
        self.rig.nodes = [node1, node2]
        
        # Add a test beam
        beam1 = Beam("node1", "node2", 9000000, 12000, 1000000, 400000)
        self.rig.beams = [beam1]
        
        is_valid = self.rig.validate()
        self.assertTrue(is_valid)
    
    def test_validation_orphaned_beams(self):
        """Test validation with orphaned beams"""
        # Add nodes
        node1 = Node("node1", 0, 0, 0)
        self.rig.nodes = [node1]
        
        # Add beam referencing non-existent node
        beam1 = Beam("node1", "node999", 9000000, 12000, 1000000, 400000)
        self.rig.beams = [beam1]
        
        self.rig.validate()
        self.assertGreater(len(self.rig.parse_warnings), 0)
    
    def test_get_statistics(self):
        """Test statistics generation"""
        # Add test data
        node1 = Node("node1", 0, 0, 0)
        node2 = Node("node2", 1, 0, 0)
        self.rig.nodes = [node1, node2]
        
        beam1 = Beam("node1", "node2", 9000000, 12000, 1000000, 400000)
        self.rig.beams = [beam1]
        
        stats = self.rig.get_statistics()
        
        self.assertEqual(stats['nodes'], 2)
        self.assertEqual(stats['beams'], 1)
        self.assertEqual(stats['dry_weight'], 10000)
        self.assertGreater(stats['total_beam_length'], 0)
    
    def test_calculate_masses_empty(self):
        """Test mass calculation with no nodes"""
        self.rig.calculate_masses()
        self.assertGreater(len(self.rig.parse_errors), 0)
    
    def test_calculate_masses_basic(self):
        """Test basic mass calculation"""
        # Add load-bearing nodes
        node1 = Node("node1", 0, 0, 0)
        node1.load_bearer = True
        node2 = Node("node2", 1, 0, 0)
        node2.load_bearer = True
        self.rig.nodes = [node1, node2]
        
        # Add beam
        beam1 = Beam("node1", "node2", 9000000, 12000, 1000000, 400000)
        self.rig.beams = [beam1]
        
        self.rig.calculate_masses()
        
        # Check that masses were calculated
        self.assertGreater(node1.mass, 0)
        self.assertGreater(node2.mass, 0)
        self.assertGreaterEqual(node1.mass, self.rig.minimass)
        self.assertGreaterEqual(node2.mass, self.rig.minimass)


class TestRigParser(unittest.TestCase):
    """Test rig parser functions"""
    
    def test_parse_node_name(self):
        """Test node name parsing"""
        # Test numeric node
        self.assertEqual(parser.ParseNodeName("123"), "node123")
        
        # Test named node
        self.assertEqual(parser.ParseNodeName("frontwheel"), "frontwheel")
    
    def test_parse_group_name(self):
        """Test group name parsing"""
        self.assertEqual(parser.ParseGroupName("wheel.mesh"), "wheel_mesh")
        self.assertEqual(parser.ParseGroupName("body.dae"), "body_dae")
    
    def test_prepare_line(self):
        """Test line preparation"""
        # Test comment line
        self.assertIsNone(parser.PrepareLine("; this is a comment"))
        
        # Test empty line
        self.assertIsNone(parser.PrepareLine(""))
        
        # Test normal line
        components = parser.PrepareLine("nodes")
        self.assertEqual(components, ["nodes"])
        
        # Test line with data
        components = parser.PrepareLine("1, 0.0, 0.0, 0.0")
        self.assertEqual(len(components), 4)


class TestFileOperations(unittest.TestCase):
    """Test file operations"""
    
    def test_parse_invalid_file(self):
        """Test parsing non-existent file"""
        rig = Rig()
        
        with self.assertRaises(RigParseError):
            rig.from_file("nonexistent.truck")
    
    def test_parse_empty_file(self):
        """Test parsing empty file"""
        rig = Rig()
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.truck', delete=False) as f:
            temp_path = f.name
        
        try:
            with self.assertRaises(RigParseError):
                rig.from_file(temp_path)
        finally:
            os.unlink(temp_path)
    
    def test_parse_minimal_truck(self):
        """Test parsing minimal valid truck file"""
        truck_content = """Test Truck
nodes
1, 0.0, 0.0, 0.0, l
2, 1.0, 0.0, 0.0, l

beams
1, 2

globals
1000, 500

end
"""
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.truck', delete=False) as f:
            f.write(truck_content)
            temp_path = f.name
        
        try:
            rig = Rig()
            rig.from_file(temp_path)
            
            self.assertEqual(rig.name, "Test Truck")
            self.assertEqual(len(rig.nodes), 2)
            self.assertEqual(len(rig.beams), 1)
            self.assertEqual(rig.dry_weight, 1000)
            self.assertEqual(rig.load_weight, 500)
            
        finally:
            os.unlink(temp_path)


class TestConfigManager(unittest.TestCase):
    """Test configuration management"""
    
    def setUp(self):
        """Set up test fixtures"""
        self.config_manager = ConfigManager()
    
    def test_default_settings(self):
        """Test default settings"""
        settings = self.config_manager.settings
        self.assertEqual(settings.minimum_mass, 50.0)
        self.assertEqual(settings.default_author, "truck2jbeam converter")
        self.assertTrue(settings.pretty_print)
    
    def test_default_templates(self):
        """Test default templates"""
        templates = self.config_manager.list_templates()
        self.assertIn("car", templates)
        self.assertIn("truck", templates)
        self.assertIn("airplane", templates)
        self.assertIn("trailer", templates)
    
    def test_get_template(self):
        """Test template retrieval"""
        car_template = self.config_manager.get_template("car")
        self.assertIsNotNone(car_template)
        self.assertEqual(car_template.name, "car")
        self.assertEqual(car_template.settings.minimum_mass, 25.0)
    
    def test_apply_template(self):
        """Test template application"""
        original_mass = self.config_manager.settings.minimum_mass
        
        success = self.config_manager.apply_template("car")
        self.assertTrue(success)
        self.assertNotEqual(self.config_manager.settings.minimum_mass, original_mass)
        self.assertEqual(self.config_manager.settings.minimum_mass, 25.0)
    
    def test_save_load_config(self):
        """Test configuration save/load"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            temp_path = Path(f.name)
        
        try:
            # Modify settings
            self.config_manager.settings.minimum_mass = 123.45
            self.config_manager.settings.default_author = "Test Author"
            
            # Save config
            success = self.config_manager.save_config(temp_path)
            self.assertTrue(success)
            self.assertTrue(temp_path.exists())
            
            # Create new config manager and load
            new_config = ConfigManager()
            new_config.config_path = temp_path
            success = new_config.load_config()
            self.assertTrue(success)
            
            # Verify settings were loaded
            self.assertEqual(new_config.settings.minimum_mass, 123.45)
            self.assertEqual(new_config.settings.default_author, "Test Author")
            
        finally:
            if temp_path.exists():
                temp_path.unlink()


def run_tests():
    """Run all tests"""
    # Create test suite
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()
    
    # Add test cases
    suite.addTests(loader.loadTestsFromTestCase(TestVectorFunctions))
    suite.addTests(loader.loadTestsFromTestCase(TestRigClass))
    suite.addTests(loader.loadTestsFromTestCase(TestRigParser))
    suite.addTests(loader.loadTestsFromTestCase(TestFileOperations))
    suite.addTests(loader.loadTestsFromTestCase(TestConfigManager))
    
    # Run tests
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    return result.wasSuccessful()


if __name__ == "__main__":
    success = run_tests()
    exit(0 if success else 1)
